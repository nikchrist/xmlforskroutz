<?php 

/* Silence is golden */

?>